# -*-coding: utf-8-*-
import os
import psycopg2
import urlparse
import handling_message
import sys
import regularexpression
reload(sys)
sys.setdefaultencoding('utf8')

from flask import Flask, request
import json
import requests
import re
import random


app = Flask(__name__)  #flask object run

# This needs to be filled with the Page Access Token that will be provided
# by the Facebook App that will be created.

PAT="EAADh50bW6lMBALjfgV2iGdNnncJyHhTe6ZCuswgIEfXhkB6V1ZC9qy7pcjF7SlVbxvvTNEwj1ZARFWZBGW1ZAzV542A9WMGX6ZAiZAgvZB2qFzHl30KTk34CcdRFmjoRgfNNm2m0Tk3ZCqTmPueGN3s8AUbivptAtQNuax8ykHBRPTAZDZD"
today_exercise = ""

@app.route('/', methods=['GET'])
def handle_verification():
  print "Handling Verification."
  if request.args.get('hub.verify_token', '') == 'himchanharu':
    print "Verification successful!"
    return request.args.get('hub.challenge', '')
  else:
    print "Verification failed!"
    return 'Error, wrong validation token'

@app.route('/', methods=['POST'])
def handle_messages():
  print "Handling Messages"
  conn = db_init()
  cur = conn.cursor()
  temp = ""
  payload = request.get_data()
  print "----payload----\n  " + payload
  for sender, message in messaging_events(payload):
    print "Incoming from %s: %s" % (sender, message)
    last_record = get_user_current_record(cur)
    print last_record
    if(last_record[2] == 'c'):
	last_record = "chest"
    elif(last_record[2] == 'b'):
	last_record = "back"
    elif(last_record[2] == 'l'):
	last_record = "lower body"
    else:
	last_record = "shoulder" 
   
    exercise_list = ["chest", "back", "lower body", "shoulder"]
    temp_exercise_list = exercise_list[:]
    temp_exercise_list.remove(last_record)
    today_exercise = temp_exercise_list[random.randrange(0,3)]

    if(message != temp and message != "I can't echo this"):
	unicode_hello = u"안녕".encode('unicode_escape')
	unicode_hey = u"야".encode('unicode_escape')
	if(message == unicode_hey):
		message = u"네?".encode("unicode_escape")
		send_message(PAT, sender, message)
		return "ok"
	if(message == unicode_hello):
	    message = u"안녕하세요".encode('unicode_escape')
            send_message(PAT, sender, message)
	    return "ok"

	service_type = handling_message.get_service_type(message)
	if(service_type == "start"):
		message = u"운동을 시작합니다! 화이팅!".encode('unicode_escape')
		send_message(PAT, sender, message)
		message = u"오늘은 어디 운동 하실건가요? ".encode('unicode_escape') 
		send_message(PAT, sender, message)
		message = u"가슴, 등, 하체, 어깨 중 하나를 골라주세요 ".encode('unicode_escape') 
		send_message(PAT, sender, message)
	        return "ok"


	elif(service_type == "chest" or service_type == "lower_body" or service_type == "back" or service_type == "shoulder"):
		temp = "%s 운동을 시작합니다!" %service_type
		today_exercise = service_type
		print "today_exercise : " , today_exercise
		message = u"" + temp
		message = message.encode('unicode_escape')
		send_message(PAT, sender, message)
		if(service_type == "lower_body"):
			service_type = "lower body"
		recommended_exercise = get_recommend_exercise(cur, service_type)
		recommended_exercise = u"" + recommended_exercise
		recommended_exercise = recommended_exercise.encode('unicode_escape')
		send_message(PAT, sender, recommended_exercise)
		update_user_current_record(conn, service_type )
		return "ok"
		
	elif(service_type == "recommend"):
		temp_msg = "어제 %s운동을 하셨으니 오늘은 %s 운동을 하시는게 좋을 것 같아요!" %(last_record, today_exercise) 
		temp_msg = u"" + temp_msg
		message = temp_msg.encode('unicode_escape') 
		send_message(PAT, sender, message)
		message = u"가슴, 등, 하체, 어깨 중 하나를 골라주세요 ".encode('unicode_escape') 
		send_message(PAT, sender, message)
		return "ok"

	elif(service_type == "stop"):
		message = u"오늘 운동을 종료합니다. 오늘 운동하신 부위가 업데이트 됩니다.".encode('unicode_escape') 
		send_message(PAT, sender, message)
		return "ok"

	elif(service_type == "record"):
		message = u"----가장 최근운동 결과----".encode('unicode_escape') 
		send_message(PAT, sender, message)
		temp = get_user_current_record(cur)
		message = u"" + temp
		send_message(PAT, sender, message)
		return "ok"

	else :
            exercise_type = regularexpression.what_exercise(message)
	     
	    noneRE = re.compile("none", re.I)
	    if(exercise_type==None):
		cur_message = handling_message.unhandled()
		send_message(PAT, sender, cur_message)
	    else:
		temp = "%s의 정보를 알고 싶으시다면?" %exercise_type
		message = u"" + temp
		message = message.encode('unicode_escape')
		send_message(PAT, sender, message)
		message = select_key_word(exercise_type, cur)
		send_message(PAT, sender, message)


  return "ok"

def messaging_events(payload):
  """Generate tuples of (sender_id, message_text) from the
  provided payload.
  """
  data = json.loads(payload)
  messaging_events = data["entry"][0]["messaging"]
  for event in messaging_events:
    if "message" in event and "text" in event["message"]:
      yield event["sender"]["id"], event["message"]["text"].encode('unicode_escape')
    else:
      yield event["sender"]["id"], "I can't echo this"


def send_message(token, recipient, text):
  """Send the message text to recipient with id recipient.
  """

  r = requests.post("https://graph.facebook.com/v2.6/me/messages",
    params={"access_token": token},
    data=json.dumps({
      "recipient": {"id": recipient},
      "message": {"text": text.decode('unicode_escape')}
    }),
    headers={'Content-type': 'application/json'})
  if r.status_code != requests.codes.ok:
    print r.text


def db_init():
	urlparse.uses_netloc.append("postgres")
	url = urlparse.urlparse("postgres://ctlddazaiokbrt:RVJzr6ixPkSJd0dCiR7FVpMxab@ec2-50-17-255-6.compute-1.amazonaws.com:5432/ddbogtipevlsq4")
	conn = psycopg2.connect(
	    database = url.path[1:],
	    user = url.username,
	    password = url.password,
	    host = url.hostname,
	    port = url.port
	)
	return conn;
	cur = conn.cursor()
	return cur

	print "----DEBUG psql----"
	cur.execute("SELECT * FROM TEST;")
	rows = cur.fetchall()
	for row in rows:
		print row

def select_key_word(keyword,cur):
   tempSQL = "select exer_link from health where exer_name = '%s';" % keyword
   print tempSQL
   cur.execute(tempSQL)
   row = cur.fetchall()
   return str(row[0])


def get_recommend_exercise(cur, part):
	temp = "select exer_order from routine where exer_part = '%s'" % part
	print temp
	cur.execute(temp)
	rows = cur.fetchall()
	return str(rows[0])


def get_user_current_record(cur):
	cur.execute("select distinct userHealth.exer_part from userHealth, routine where userHealth.exer_part = routine.exer_part AND user_id = 'himchan123';")
	rows = cur.fetchall()
	return str(rows[0])

def update_user_current_record(conn, part):
	temp = "update userHealth set exer_part = '%s' where user_id = 'himchan123';" %part
	conn.cursor().execute(temp)
	conn.commit()
	
	

if __name__ == '__main__':
    app.run()


