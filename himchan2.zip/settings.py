import dj_database_url
import os

DATABASES = {
	'default':{
		'ENGINE':'django.db.backends.postgresql_psycopg2',
		'NAME' : 'ddbogtipevlsq4',
		'USER' : 'ctlddazaiokbrt',
		'PASSWORD' : 'RVJzr6ixPkSJd0dCiR7FVpMxab',
		'HOST' : 'ec2-50-17-255-6.compute-1.amazonaws.com',
		'PORT' : '5432',
}
}
TIME_ZONE = 'Asia/Seoul'

